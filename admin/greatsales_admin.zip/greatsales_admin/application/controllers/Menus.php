<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menus extends CI_Controller {

	
	public function category_list()
	{
		$this->load->view('category_list');
	}
	public function category_add()
	{
		$this->load->view('category_add');
	}
}
